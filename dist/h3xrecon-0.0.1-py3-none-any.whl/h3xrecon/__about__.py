# SPDX-FileCopyrightText: 2024-present h3xit <h3xit@protonmail.com>
#
# SPDX-License-Identifier: MIT
__version__ = "0.0.1"
